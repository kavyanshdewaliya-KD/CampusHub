// This file must be served from the site root (e.g. https://yoursite.vercel.app/firebase-messaging-sw.js)
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyBURkftN68dMpRFrnWBdca0qs1QmpQlzQ0",
  authDomain: "ietcse-bb0c9.firebaseapp.com",
  databaseURL: "https://ietcse-bb0c9-default-rtdb.firebaseio.com",
  projectId: "ietcse-bb0c9",
  storageBucket: "ietcse-bb0c9.firebasestorage.app",
  messagingSenderId: "39297300181",
  appId: "1:39297300181:web:08b6d3e5bae40b9c19145c",
});

const messaging = firebase.messaging();

// Handles pushes that arrive while the app/tab is closed or backgrounded
messaging.onBackgroundMessage((payload) => {
  const title = payload.notification?.title || 'CampusHub';
  const options = {
    body: payload.notification?.body || '',
    icon: '/icon-192.png',
  };
  self.registration.showNotification(title, options);
});
